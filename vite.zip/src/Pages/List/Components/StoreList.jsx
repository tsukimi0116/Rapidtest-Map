import React, { useEffect, useState } from "react";
import { Card, Modal } from "antd";
import Axios from "axios";

const StoreList = ({ searchData }) => {
    const [initData, setInitData] = useState([])

    const [Data, setData] = useState([]);

    const storeData = [];

    // const [store, setStore] = useState([]);

    const dataset = async () => {
        try {
            let result = await Axios.get('https://data.nhi.gov.tw/Datasets/Download.ashx?rid=A21030000I-D03001-001&l=https://data.nhi.gov.tw/resource/Nhi_Fst/Fstdata.csv')

            let totalData = result.data.split(',')

            let hospitalFunc = () => {
                let result = totalData.filter(function (item, index, array) {
                    return index % 9 === 1;
                })
                result.shift();
                return result
            }

            let addressFunc = () => {
                let result = totalData.filter(function (item, index, array) {
                    return index % 9 === 2;
                })
                result.shift();
                return result
            }

            let phoneFunc = () => {
                let result = totalData.filter(function (item, index, array) {
                    return index % 9 === 5;
                })
                result.shift();
                return result
            }

            let nameFunc = () => {
                let result = totalData.filter(function (item, index, array) {
                    return index % 9 === 6;
                })
                result.shift();
                return result
            }

            let numFunc = () => {
                let result = totalData.filter(function (item, index, array) {
                    return index % 9 === 7;
                })
                result.shift();
                return result;
            }

            let remarkFunc = () => {
                let result = totalData.filter(function (item, index, array) {
                    return index % 9 === 0;
                })
                result.shift();
                return result;
            }

            let hospitalArray = hospitalFunc();
            let addressArray = addressFunc();
            let phoneArray = phoneFunc();
            let nameArray = nameFunc();
            let numArray = numFunc();
            let remarkArray = remarkFunc();

            let fordata = []
            for (let i = 0; i < hospitalArray.length; i++) {
                fordata.push({
                    hospital: hospitalArray[i],
                    address: addressArray[i],
                    phone: phoneArray[i],
                    name: nameArray[i],
                    num: numArray[i],
                    remark: remarkArray[i]
                })
            }
            setData(fordata)

            let init = fordata.filter(function (val, idx, arr) {
                return idx < 10;
            })

            setInitData(init);

        }
        catch (error) {
            console.log(error)
        }

    }
    useEffect(() => {
        if (searchData.country !== undefined && (searchData.storename === undefined)) {
            let result = Data.filter(function (val, idx, arr) {
                return val.address.includes(searchData.country)
            })
            setInitData(result);
        }
        else if (searchData.country !== undefined && (searchData.storename === '')) {
            let result = Data.filter(function (val, idx, arr) {
                return val.address.includes(searchData.country)
            })
            setInitData(result);
        }
        else if (searchData.country !== undefined && searchData.storename !== undefined) {
            let result = Data.filter(function (val, idx, arr) {
                return val.address.includes(searchData.country)
            })
            let result2 = result.filter(function (val, idx, arr) {
                return val.hospital.includes(searchData.storename)
            })
            setInitData(result2);
        }
        else {
            dataset();
        }

    }, [searchData]);


    const onClick = (event) => {
        Modal.confirm({
            title: '是否儲存此筆店家',
            okText: '儲存',
            cancelText: '返回',
            onOk: () => {
                let text = event.nativeEvent.path[2].innerText;
                let storeArray = text.split('\n\n')
                let storeobj = {
                    num: storeArray[0],
                    hospital: storeArray[1],
                    address: storeArray[2],
                    name: storeArray[3],
                    remark: storeArray[4]
                }
                storeData.push(storeobj)
                sessionStorage.setItem('store', JSON.stringify(storeData))
            }
        })
        console.log(event);
    }

    return (
        <div className='ListCard'>
            {Array.isArray(initData) &&
                initData.map((element, index) => (
                    <Card onClick={onClick} key={index} style={{ width: 350 }}>
                        <span>剩餘數量:{element.num}</span>
                        <p>{element.hospital} {element.phone}</p>
                        <p>{element.address}</p>
                        <p>{element.name}</p>
                        <p>{element.remark}</p>
                    </Card>
                ))}
        </div>

    )
}

export default StoreList;